export default async function Salut(){
    return "Bonjour je m'applle Next";
}